//
//  Conditions.swift
//  Coursework2
//
//  Created by G Lukka.
//

import SwiftUI

struct CurrentWeatherView: View {
    @EnvironmentObject var modelData: ModelData
    
    @State var locationString: String = "No location"
    
    var body: some View {
        ZStack {
            // Background Image rendering code here
            Image("background2")
                .resizable()
                .ignoresSafeArea()
            
            
            VStack {
//                Text(locationString)
//                    .font(.title)
//                    .foregroundColor(.black)
//                    .shadow(color: .black, radius: 0.5)
//                    .multilineTextAlignment(.center)
                
                Text("\(modelData.userLocation)")
                
                Text("\((Int)(modelData.forecast!.current.temp))ºC")
                    .padding()
                    .font(.largeTitle)
                
                HStack {
                    AsyncImage(url: URL(string: "https://openweathermap.org/img/wn/\(modelData.forecast!.current.weather[0].icon)@2x.png"))
                    
                    Text("\(modelData.forecast!.current.weather[0].weatherDescription.rawValue.capitalized)")
                        .padding()
                        .font(.title2)
                        .foregroundColor(.black)
                        .shadow(color: .black, radius: 0.5)
                }
                
                Text("Feels Like: \((Int)(modelData.forecast!.current.feelsLike))ºC")
                    .foregroundColor(.black)
                
                HStack {
                    Text("Wind Speed: \((Int)(modelData.forecast!.current.windSpeed)) m/s")
                    Spacer()
                    
                    //Text("Direction: \(modelData.forecast!.current.windDeg)")
                    Text("Direction: \(convertDegToCardinal(deg: modelData.forecast!.current.windDeg))")
                }.padding()
                
                HStack {
                    Text("Humidity: \((Int)(modelData.forecast!.current.humidity)) %")
                    Spacer()
                    
                    Text("Pressure: \((Int)(modelData.forecast!.current.pressure)) hPg")
                }.padding()
                
                HStack {
                    Label("\(Date(timeIntervalSince1970: TimeInterval(((Int)(modelData.forecast?.current.sunset ?? 0)))).formatted(.dateTime.hour().minute()))",systemImage: "sunset.fill")
                    
                    
                    Label("\(Date(timeIntervalSince1970: TimeInterval(((Int)(modelData.forecast?.current.sunrise ?? 0)))).formatted(.dateTime.hour().minute()))",systemImage: "sunset.fill")
                    
                }.padding()
            }.onAppear {
                Task.init {
                    self.locationString = await getLocFromLatLong(lat: modelData.forecast!.lat, lon: modelData.forecast!.lon)
                    self.modelData.userLocation = locationString
                }
            }
        }
    }
}

struct Conditions_Previews: PreviewProvider {
    static var previews: some View {
        CurrentWeatherView()
            .environmentObject(ModelData())
    }
}
