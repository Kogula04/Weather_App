//
//  PollutionView.swift
//  Coursework2
//
//  Created by GirishALukka on 30/12/2022.
//

import SwiftUI

struct PollutionView: View {
    
    // @EnvironmentObject and @State varaibles here
    @EnvironmentObject var modelData: ModelData
    @State var locationString: String = "No location"
    

    var body: some View {
        
        ZStack {

            // Use ZStack for background images
            Image("background")
                .resizable()
                .ignoresSafeArea()
            
            VStack {
                Text("\(modelData.userLocation)")
                Spacer()
                
                Text("\((Int)(modelData.forecast!.current.temp))ºC")
                    .padding()
                    .font(.largeTitle)
                
                HStack {
                    AsyncImage(url: URL(string: "https://openweathermap.org/img/wn/\(modelData.forecast!.current.weather[0].icon)@2x.png"))
                    
                    Text("\(modelData.forecast!.current.weather[0].weatherDescription.rawValue.capitalized)")
                        .padding()
                        .font(.title2)
                        .foregroundColor(.black)
                        .shadow(color: .black, radius: 0.5)
                }
                Text("H: \((Int)(modelData.forecast!.current.temp)) °C")
                
                //\((Int)(day.temp.min))
                
                Text("Feels Like: \((Int)(modelData.forecast!.current.feelsLike))ºC")
                    .foregroundColor(.black)
                
                Spacer()
                Text("")
                Spacer()

                }
            }
            .onAppear {
                Task {
                    try await modelData.loadAirPollutionData()
                }
            }
        }
    }

    

