//
//  AirPollutionModelData.swift
//  CourseWork2Starter
//
//  Created by Kogula on 2023-03-31.
//

import Foundation

struct AirPollutionModelData: Codable {
    let coord: Coord
    let list: [AirPollutionList]
}

struct Coord: Codable {
    let lon: Double
    let lat: Double
}

struct AirPollutionList: Codable {
    let main: AirPollutionMain
    let components: AirPollutionComponents
    let dt: Int
    
}

struct AirPollutionMain: Codable {
    let aqi: Int
    
}

struct AirPollutionComponents: Codable {
    let co: Double
    let no: Double
    let no2: Double
    let o3: Double
    let so2: Double
    let pm2_5: Double
    let pm10: Double
    let nh3: Double
}
