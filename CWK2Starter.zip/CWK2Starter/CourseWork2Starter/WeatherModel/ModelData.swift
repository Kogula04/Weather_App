import Foundation
class ModelData: ObservableObject {
    @Published var forecast: Forecast?
    @Published  var userLocation: String = ""
    @Published var airPollution: AirPollutionModelData?
    
    init() {
        self.forecast = load("london.json")
    }
    

    func loadData(lat: Double, lon: Double) async throws -> Forecast {
        let url = URL(string: "https://api.openweathermap.org/data/3.0/onecall?lat=\(lat)&lon=\(lon)&units=metric&appid=5fc7ce5b7a23a64c6d7f364e3a0325c3")
        let session = URLSession(configuration: .default)
        
        let (data, _) = try await session.data(from: url!)
        
        do {
            //print(data)
            let forecastData = try JSONDecoder().decode(Forecast.self, from: data)
            DispatchQueue.main.async {
                self.forecast = forecastData
            }
            
            return forecastData
        } catch {
            throw error
        }
    }
    
    //created the fun without the param
    func loadAirPollutionData() async throws {
        
        guard let lat = forecast?.lat, let lon = forecast?.lon else {
            fatalError("Couldn't find in lat & lon in forecast data.")
        }
        
        let urlString = "https://api.openweathermap.org/data/2.5/air_pollution?lat=\(lat)&lon=\(lon)&units=metric&appid=5fc7ce5b7a23a64c6d7f364e3a0325c3"
        
        let url = URL(string: urlString)
        
        let session = URLSession(configuration: .default)
        
        let (data, _) = try await session.data(from: url!)
        
        do {
            let pollutionData = try JSONDecoder().decode(AirPollutionModelData.self, from: data)
            print("aqi: \(pollutionData.list[0].main.aqi)")
            print("no: \(pollutionData.list[0].components.no)")
            print("co: \(pollutionData.list[0].components.co)")
            print("no2: \(pollutionData.list[0].components.no2)")
            print("03: \(pollutionData.list[0].components.o3)")
            print("so2: \(pollutionData.list[0].components.so2)")
            print("pm2_5: \(pollutionData.list[0].components.pm2_5)")
            print("pm10: \(pollutionData.list[0].components.pm10)")
            print("nh3: \(pollutionData.list[0].components.nh3)")
            
            
        } catch {
            
        }
        
        
    }
    
    
    func load<Forecast: Decodable>(_ filename: String) -> Forecast {
        let data: Data
        
        guard let file = Bundle.main.url(forResource: filename, withExtension: nil)
        else {
            fatalError("Couldn't find \(filename) in main bundle.")
        }
        
        do {
            data = try Data(contentsOf: file)
        } catch {
            fatalError("Couldn't load \(filename) from main bundle:\n\(error)")
        }
        
        do {
            let decoder = JSONDecoder()
            return try decoder.decode(Forecast.self, from: data)
        } catch {
            fatalError("Couldn't parse \(filename) as \(Forecast.self):\n\(error)")
        }
    }
}
